package com.example.lenovo.hospitalhelp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout mDrawerLAyout;
    private ActionBarDrawerToggle mToggle;
    private EditText editpostalcode;
    private Button buttonConfirm;
     public static final Pattern POSTALCODE_PATTERN =
             Pattern.compile("^(?!.*[DFIOQU])[A-VXY][0-9][A-Z] ?[0-9][A-Z][0-9]$");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editpostalcode = findViewById(R.id.postal_code);
        buttonConfirm = (Button) findViewById(R.id.button_confirm);
        buttonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String str = editpostalcode.getText().toString();
                Intent intent =  new Intent(getApplicationContext(),RidedetailsActivity.class);
                intent.putExtra("message",str);
                startActivity(intent);
            }
        });
        editpostalcode.addTextChangedListener(loginTextWatcher);
        mDrawerLAyout = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLAyout, R.string.open, R.string.close);
        mDrawerLAyout.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);
    }
public void MainActivity(){


}

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String postalcodeInput = editpostalcode.getText().toString().trim();
            if (postalcodeInput.isEmpty()){
                editpostalcode.setError("Field Cant be empty"); }
                else if (!POSTALCODE_PATTERN.matcher(postalcodeInput).matches()){
                editpostalcode.setError("Postal Code Not Valid");
            }

            buttonConfirm.setEnabled(!postalcodeInput.isEmpty());
        }
        @Override
        public void afterTextChanged(Editable editable) {

        }
    }
;


    @Override

    public boolean onOptionsItemSelected(MenuItem item) {

        if (mToggle.onOptionsItemSelected(item)) {
            return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.profile) {
            Intent myintent = new Intent(MainActivity.this,
                    ProfileActivity.class);
            startActivity(myintent);

        }
        if (id == R.id.payment)
        {
            Intent pintent = new Intent(MainActivity.this,PaymentActivity.class);
            startActivity(pintent);

        }

            return false;
        }



}
