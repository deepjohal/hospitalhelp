package com.example.lenovo.hospitalhelp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class PaymentActivity extends AppCompatActivity {
    DatabaseHelper1 databaseHelper1;
    EditText editcreditcard, editcreditcardexpiry;
    Button Savedata;
    public static final Pattern CREDITCARD_PATTERN =
            Pattern.compile("^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14})$");
    public static final Pattern CREDITCARDEXPIRY_PATTERN =
            Pattern.compile("^((0[1-9])|(1[0-2]))\\/((2009)|(20[1-2][0-9]))$\n");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        databaseHelper1 = new DatabaseHelper1(this);
        editcreditcard = (EditText)findViewById(R.id.editText);
        editcreditcardexpiry = (EditText)findViewById(R.id.editText1);
        Savedata = (Button)findViewById(R.id.btnsave);
        editcreditcard.addTextChangedListener(loginTextWatcher);
        addData();
    }


    public void addData() {
        Savedata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isInserted = databaseHelper1.insertData(editcreditcard.getText().toString(),
                        editcreditcardexpiry.getText().toString());
                if (isInserted == true) {
                    Toast.makeText(PaymentActivity.this, "Data Added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PaymentActivity.this, "Data NOT Added", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

private TextWatcher loginTextWatcher = new TextWatcher() {
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2)
    {
        String creditcardinput = editcreditcard.getText().toString().trim();
        if (creditcardinput.isEmpty()) {
            editcreditcard.setError("Field cant be empty");
        } else if (!CREDITCARD_PATTERN.matcher(creditcardinput).matches()) {
            editcreditcard.setError("Credit Card Not Valid");
        }

            Savedata.setEnabled(!creditcardinput.isEmpty());

        String expiryinput = editcreditcardexpiry.getText().toString().trim();
        if(expiryinput.isEmpty()){
            editcreditcardexpiry.setError("Field cant be empty");
        }
        else if (!CREDITCARDEXPIRY_PATTERN.matcher(expiryinput).matches()){
            editcreditcardexpiry.setError("Expiry Date not valid");
        }
        Savedata.setEnabled(!expiryinput.isEmpty());
    }


    @Override
    public void afterTextChanged(Editable editable) {

    }
};}

